using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using APPMICROCREDITO.Models;

namespace APPMICROCREDITO.Controllers;

public class CreditoController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public CreditoController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Registrar(Credito credito){

        if (!ModelState.IsValid){
            ViewData["Message"] = "Por favor, complete correctamente todos los campos.";
            return View("Index");
        }


        bool fechaValida = credito.FecCon.HasValue && (DateTime.Now - credito.FecCon.Value).TotalDays >= 90;
        bool montoValido = credito.Monto.HasValue && credito.Salario.HasValue && credito.Monto <= (credito.Salario * 0.3);
        bool creditoAprobado = false;


        if (credito.Salario > 2000 && (credito.FrecPago == "Quincenal" || credito.FrecPago == "Mensual")){
            creditoAprobado = true;
        }else if (credito.Salario <= 2000 && credito.FrecPago == "Semanal"){
            creditoAprobado = true;
        }

        
        if (!fechaValida){
            ViewData["Message"] = "Debe tener al menos 3 meses de contratación.";
        }else if (!montoValido){
            ViewData["Message"] = "No puede solicitar más del 30% de su salario.";
        }else if (!creditoAprobado){
            ViewData["Message"] = "No cumple con los requisitos salariales para acceder al crédito.";
        }else{
            ViewData["Message"] = $"SE ACEPTÓ SU SOLICITUD.<br>" +
                                $"Nombres: {credito.Nombres}<br>" +
                                $"DNI: {credito.Dni}<br>" +
                                $"Fecha de Contratación: {credito.FecCon?.ToShortDateString()}<br>" +
                                $"Salario: {credito.Salario}<br>" +
                                $"Frecuencia de Pago: {credito.FrecPago}<br>" +
                                $"Monto Solicitado: {credito.Monto}";
        }

        return View("Index", credito);
    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
