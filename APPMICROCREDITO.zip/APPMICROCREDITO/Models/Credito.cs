using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace APPMICROCREDITO.Models{
    public class Credito{
        [Required(ErrorMessage = "Es obligatorio llenar este campo")]
        public string? Nombres {get; set;}

        [Required(ErrorMessage = "Es obligatorio llenar este campo")]
        public long? Dni {get; set;}

        [Required(ErrorMessage = "Es obligatorio llenar este campo")]
        public DateTime? FecCon {get; set;}

        [Required(ErrorMessage = "Es obligatorio llenar este campo")]
        public double? Salario {get; set;}

        [Required(ErrorMessage = "Es obligatorio llenar este campo")]
        public string? FrecPago {get; set;}

        [Required(ErrorMessage = "Es obligatorio llenar este campo")]
        public double? Monto {get; set;}

        public string? Mensaje {get; set;}
    }
}